<?php

$db_host = 'localhost';

$db_nome = 'bd_easybook';

$db_usuario = 'usuario';

$db_senha = 'usuario';
?>