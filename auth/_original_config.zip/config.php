<?php

$diretorio_padrao_acesso_negado = '';

?>