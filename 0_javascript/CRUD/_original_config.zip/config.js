let config = {
    "servidor": "http://localhost/eixo3-agendamento",
    "diretorios": {
        "atendimentos": "CRUD/atendimentos",
        "avaliacoes": "CRUD/avaliacoes",
        "horarios": "CRUD/horarios",
        "prestadores": "CRUD/prestadores",
    }
}