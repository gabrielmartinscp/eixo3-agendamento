<?php

$db_host = 'localhost';

$db_nome = 'bd_easybook';

$db_tabela_dados_login_senha = 'dados_acesso';

$db_usuario = 'usuario';

$db_senha = 'usuario';

$pagina_inicial_login_bem_sucedido = '/../index';

?>